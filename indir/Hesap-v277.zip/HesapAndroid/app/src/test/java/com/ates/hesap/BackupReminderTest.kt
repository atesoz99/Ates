package com.ates.hesap
import org.junit.Assert.assertEquals
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale
class BackupReminderTest {
    private fun time(value: String) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse(value)!!.time
    @Test fun futureEvenMonthRemainsInSameYear() {
        assertEquals(time("2026-12-01 10:00:00"), nextYearlyReminder(time("2025-12-01 10:00:00"), time("2026-11-11 11:00:00")))
    }
    @Test fun deliveredOccurrenceIsRearmedForNextYear() {
        assertEquals(time("2027-02-01 10:00:00"), nextYearlyReminder(time("2026-02-01 10:00:00"), time("2026-02-01 10:00:00")))
    }
}
