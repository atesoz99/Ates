package com.ates.hesap

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

object ReminderStore {
    private const val CHANNEL = "hesap_reminders"
    private fun preferences(c: Context) = c.getSharedPreferences("hesap_reminders", Context.MODE_PRIVATE)
    private fun localFormat() = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { isLenient = false }
    private fun alarmIntent(c: Context, id: String): PendingIntent = PendingIntent.getBroadcast(c, 0, Intent(c, ReminderReceiver::class.java).setAction("com.ates.hesap.REMINDER").setData(Uri.parse("hesap://reminder/" + Uri.encode(id))).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val english = c.getSharedPreferences("hesap_native", Context.MODE_PRIVATE).getString("language", "tr") == "en"
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, if (english) "Payment and maturity reminders" else "Ödeme ve vade hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    @Synchronized fun replace(c: Context, entries: JSONArray, enabled: Boolean) {
        val prefs = preferences(c)
        val next = JSONArray()
        if (enabled) for (i in 0 until minOf(entries.length(), 60)) {
            val e = entries.optJSONObject(i) ?: continue
            val id = e.optString("id"); val body = e.optString("body"); val at = e.optLong("at")
            if (id.isBlank() || id.length > 300 || body.length > 2000 || at <= System.currentTimeMillis()) continue
            next.put(JSONObject().put("id", id).put("body", body).put("at", at).put("local", localFormat().format(Date(at))).put("repeatYearly", id.startsWith("backup-repeat-") && e.optBoolean("repeatYearly")))
        }
        val serialized = next.toString()
        if (prefs.getString("entries", "[]") == serialized && prefs.getString("zone", "") == TimeZone.getDefault().id) return
        val old = JSONArray(prefs.getString("entries", "[]"))
        val alarms = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until old.length()) old.optJSONObject(i)?.optString("id")?.let { alarms.cancel(alarmIntent(c, it)) }
        prefs.edit().putString("entries", serialized).putString("zone", TimeZone.getDefault().id).commit()
        if (!enabled) NotificationManagerCompat.from(c).cancelAll()
        scheduleStored(c)
    }
    private fun scheduleStored(c: Context) {
        createChannel(c)
        val entries = JSONArray(preferences(c).getString("entries", "[]"))
        val alarms = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until entries.length()) {
            val e = entries.optJSONObject(i) ?: continue
            var at = try { localFormat().parse(e.optString("local"))?.time ?: e.optLong("at") } catch (_: Exception) { e.optLong("at") }
            if (e.optBoolean("repeatYearly")) {
                at = nextYearlyReminder(at, System.currentTimeMillis())
            }
            if (at > System.currentTimeMillis()) {
                // Does not request restricted exact-alarm access. Android may defer reminders in Doze.
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(c, e.optString("id")))
            }
        }
    }
    @Synchronized fun reschedule(c: Context) { scheduleStored(c) }
    @Synchronized fun clear(c: Context) {
        val prefs = preferences(c); val entries = JSONArray(prefs.getString("entries", "[]"))
        val alarms = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until entries.length()) entries.optJSONObject(i)?.optString("id")?.let { alarms.cancel(alarmIntent(c, it)) }
        prefs.edit().remove("entries").remove("zone").commit()
        NotificationManagerCompat.from(c).cancelAll()
    }
    @Synchronized fun deliver(c: Context, id: String) {
        val prefs = preferences(c); val entries = JSONArray(prefs.getString("entries", "[]"))
        val entry = (0 until entries.length()).mapNotNull { entries.optJSONObject(it) }.firstOrNull { it.optString("id") == id } ?: return
        val remaining = JSONArray(); for (i in 0 until entries.length()) entries.optJSONObject(i)?.let { if (it.optString("id") != id || it.optBoolean("repeatYearly")) remaining.put(it) }
        prefs.edit().putString("entries", remaining.toString()).commit()
        if (entry.optBoolean("repeatYearly")) scheduleStored(c)
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return
        createChannel(c)
        val tap = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse("hesap://notice/" + Uri.encode(id))).putExtra("noticeId", id).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Hesap").setContentText(entry.optString("body")).setStyle(NotificationCompat.BigTextStyle().bigText(entry.optString("body"))).setContentIntent(tap).setAutoCancel(true).build()
        NotificationManagerCompat.from(c).notify(id.hashCode(), notification)
    }
}
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.ates.hesap.REMINDER") return
        val id = intent.getStringExtra("id") ?: return
        ReminderStore.deliver(context, id)
    }
}
class RescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_TIME_CHANGED)) return
        val pending = goAsync()
        Thread { try { ReminderStore.reschedule(context); SpendingWidget.updateAll(context) } finally { pending.finish() } }.start()
    }
}
