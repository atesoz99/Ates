package com.ates.hesap

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var webContext: android.view.ContextThemeWrapper
    private lateinit var root: FrameLayout
    private lateinit var progress: ProgressBar
    private lateinit var errorView: TextView
    private val io = Executors.newSingleThreadExecutor()
    private var ready = false
    private var english = false
    private var dark = true
    private var exportId: String? = null
    private var exportFile: File? = null
    private var exportBusy = false
    private var importing = false
    private var pendingNotice: String? = null
    private var generation = 0
    private var resetId: String? = null
    private var dateDialog: DatePickerDialog? = null
    private val prefs by lazy { getSharedPreferences("hesap_native", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        english = prefs.getString("language", "tr") == "en"
        dark = prefs.getBoolean("dark", true)
        exportId = state?.getString("exportId")
        state?.getString("exportPath")?.let { path ->
            val file = File(path)
            if (file.parentFile?.canonicalFile == cacheDir.canonicalFile && file.name == "pending-backup.json") exportFile = file
        }
        importing = state?.getBoolean("importing") ?: false
        pendingNotice = state?.getString("pendingNotice") ?: intent.getStringExtra("noticeId")
        if (exportId == null) File(cacheDir, "pending-backup.json").delete()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        root = FrameLayout(this)
        // The native select dialog inherits the WebView context, not CSS color-scheme.
        webContext = android.view.ContextThemeWrapper(this, if (dark) R.style.Theme_Hesap_Web_Dark else R.style.Theme_Hesap_Web_Light)
        web = WebView(webContext)
        progress = ProgressBar(this)
        errorView = TextView(this).apply {
            textSize = 17f; gravity = android.view.Gravity.CENTER; setPadding(24, 24, 24, 24)
            visibility = View.GONE
            setOnClickListener { loadApp() }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(64, 64, android.view.Gravity.CENTER))
        root.addView(errorView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val keyboard = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboard.bottom))
            // Native padding owns system bars and IME; do not pass the same insets to WebView.
            WindowInsetsCompat.CONSUMED
        }
        applyNativeTheme()
        with(web.settings) {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            showLoadError(text("Android System WebView uygulamasını güncelleyin.", "Please update Android System WebView.")); return
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) WebViewCompat.addWebMessageListener(web, "AndroidHesap", setOf(APP_ORIGIN)) { _, message, origin, mainFrame, _ ->
            if (!mainFrame || origin.toString().trimEnd('/') != APP_ORIGIN || message.data == null) return@addWebMessageListener
            val raw = message.data!!
            if (raw.length > MAX_BACKUP + 8192) return@addWebMessageListener
            try { onBridge(JSONObject(raw)) } catch (_: Exception) { sendError(text("İşlem tamamlanamadı.", "The operation could not be completed.")) }
        }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/") { path ->
            when (path) {
                "finans-ilk-prototip.html" -> {
                    val html = assets.open(path).bufferedReader().use { it.readText() }
                    // WebView already lies inside the native safe area. Avoid applying CSS safe-area padding twice.
                    val androidHtml = html.replace(Regex("env\\(safe-area-inset-(?:top|right|bottom|left)\\)"), "0px")
                    val injected = androidHtml.replaceFirst("<head>", "<head><script src=\"/assets/android-bridge.js\"></script><link rel=\"stylesheet\" href=\"/assets/android-ui.css\">")
                    WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(injected.toByteArray()))
                }
                "android-ui.css" -> WebResourceResponse("text/css", "UTF-8", assets.open(path))
                "android-bridge.js" -> WebResourceResponse("application/javascript", "UTF-8", assets.open(path))
                else -> null
            }
        }.build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(request.url)?.let { return it }
                // Market requests get the same HTTPS data through an allowlisted, bounded native connection.
                // This avoids depending on providers' browser CORS headers. No records or credentials are sent.
                if (request.method == "GET" && MarketTransport.allowed(request.url)) return MarketTransport.fetch(request.url)
                return MarketTransport.error(403, "Blocked")
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return true
                if (request.url.toString() == APP_URL) return false
                openExternal(request.url); return true
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { ready = false; generation++ }
            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == APP_URL) pageReady()
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showLoadError(text("Uygulama açılamadı. Tekrar denemek için dokunun.", "Unable to open the app. Tap to retry."))
            }
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Recreate the activity; WebView local storage is durable and financial records remain intact.
                ready = false; view.destroy(); recreate(); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message).setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }.setOnCancelListener { result.cancel() }.show(); return true
            }
        }
        onBackPressedDispatcher.addCallback(this) { handleBack() }
        loadApp()
    }

    private fun loadApp() { errorView.visibility = View.GONE; progress.visibility = View.VISIBLE; web.visibility = View.VISIBLE; web.loadUrl(APP_URL) }
    private fun showLoadError(message: String) { progress.visibility = View.GONE; errorView.text = message; errorView.visibility = View.VISIBLE }
    private fun pageReady() {
        if (ready) return
        ready = true; progress.visibility = View.GONE
        if (exportId != null && exportFile?.exists() != true) { exportId?.let { deliver(JSONObject().put("type", "exportCancelled").put("requestID", it)) }; exportId = null }
        openPendingNotice()
        web.evaluateJavascript("window.Hesap?.refreshNotifications(undefined,true);", null)
    }
    private fun text(tr: String, en: String) = if (english) en else tr
    private fun applyNativeTheme() {
        if (::webContext.isInitialized) webContext.setTheme(if (dark) R.style.Theme_Hesap_Web_Dark else R.style.Theme_Hesap_Web_Light)
        val background = if (dark) Color.rgb(24, 26, 30) else Color.rgb(244, 239, 230)
        // Once the app opens, system bars follow its selected theme rather than the splash blue.
        window.statusBarColor = background
        window.navigationBarColor = background
        root.setBackgroundColor(background); web.setBackgroundColor(background)
        errorView.setBackgroundColor(background); errorView.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        WindowCompat.getInsetsController(window, root).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
    }
    private fun deliver(payload: JSONObject) {
        if (isFinishing || isDestroyed || !ready) return
        web.evaluateJavascript("window.dispatchEvent(new CustomEvent('hesap-native',{detail:JSON.parse(${JSONObject.quote(payload.toString())})}));", null)
    }
    private fun sendError(message: String, id: String? = null) {
        val payload = JSONObject().put("type", "error").put("message", message)
        if (id != null) payload.put("requestID", id)
        deliver(payload)
    }
    private fun onBridge(message: JSONObject) {
        when (message.optString("action")) {
            "ready" -> pageReady()
            "language" -> { english = message.optString("language") == "en"; prefs.edit().putString("language", if (english) "en" else "tr").apply() }
            "theme" -> { dark = message.optBoolean("dark"); prefs.edit().putBoolean("dark", dark).apply(); applyNativeTheme() }
            "pickDate" -> pickDate(message)
            "requestPermission" -> requestNotifications()
            "schedule" -> {
                val entries = message.optJSONArray("notifications") ?: org.json.JSONArray()
                val enabled = message.optBoolean("enabled", true)
                io.execute { ReminderStore.replace(this, entries, enabled) }
            }
            "export" -> export(message)
            "import" -> importFile()
            "widgetSnapshot" -> { prefs.edit().putFloat("dailyGoal", maxOf(0.0, message.optDouble("dailyGoal", 0.0)).toFloat()).putString("language", message.optString("language", "tr")).apply(); SpendingWidget.updateAll(this) }
            "resetApp" -> {
                if (exportId != null || importing) { sendError(text("Önce dosya işlemini tamamlayın.", "Please complete the file operation first."), message.optString("requestID")); return }
                val id = message.optString("requestID"); resetId = id
                io.execute { ReminderStore.clear(this); prefs.edit().remove("dailyGoal").commit(); runOnUiThread { if (resetId == id) { SpendingWidget.updateAll(this); deliver(JSONObject().put("type", "resetComplete").put("requestID", id)) } } }
            }
            "resetAborted" -> if (resetId == message.optString("requestID")) resetId = null
        }
    }
    private fun openExternal(uri: Uri) {
        if (uri.scheme !in listOf("https", "mailto")) return
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)) } catch (_: Exception) { sendError(text("Bağlantı açılamadı.", "The link could not be opened.")) }
    }
    private fun requestNotifications() {
        ReminderStore.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), PERMISSION_NOTIFICATIONS)
        else deliver(JSONObject().put("type", "permission").put("granted", getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled()))
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_NOTIFICATIONS) {
            deliver(JSONObject().put("type", "permission").put("granted", grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED))
            io.execute { ReminderStore.reschedule(this) }
        }
    }
    private fun pickDate(message: JSONObject) {
        if (dateDialog?.isShowing == true) return
        val field = message.optString("field")
        if (field !in listOf("trade-date", "term-start", "term-end")) return
        val locale = if (message.optString("language") == "en") Locale.UK else Locale.forLanguageTag("tr-TR")
        val cfg = Configuration(resources.configuration).apply { setLocale(locale) }
        val bounds = DateRules.bounds(field)
        val chosen = DateRules.parse(message.optString("value"))?.coerceIn(bounds.first, bounds.second) ?: if (field == "term-end") bounds.first else bounds.second
        val calendar = Calendar.getInstance().apply { timeInMillis = chosen }
        val theme = if (message.optBoolean("dark", true)) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        val context = android.view.ContextThemeWrapper(this, theme).apply { applyOverrideConfiguration(cfg) }
        dateDialog = DatePickerDialog(context, theme, { _, year, month, day ->
            val selected = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
            deliver(JSONObject().put("type", "dateSelected").put("field", field).put("value", selected))
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).apply {
            datePicker.minDate = bounds.first; datePicker.maxDate = bounds.second
            setOnDismissListener { dateDialog = null }
        }
        dateDialog?.show()
    }
    private fun export(message: JSONObject) {
        val id = message.optString("requestID")
        if (exportId != null || importing || exportBusy) { sendError(text("Dosya işlemi zaten sürüyor.", "A file operation is already in progress."), id); return }
        val content = message.optString("content")
        if (content.toByteArray(Charsets.UTF_8).size > MAX_BACKUP) { sendError(text("Yedek dosyası çok büyük.", "The backup is too large."), id); return }
        try { JSONObject(content) } catch (_: Exception) { sendError(text("Yedek oluşturulamadı.", "Could not create the backup."), id); return }
        exportId = id; exportBusy = true
        val pageGeneration = generation
        io.execute {
            try {
                val file = File(cacheDir, "pending-backup.json"); file.writeText(content, Charsets.UTF_8)
                runOnUiThread {
                    exportBusy = false
                    if (generation != pageGeneration || isFinishing || isDestroyed) { file.delete(); exportId = null; return@runOnUiThread }
                    exportFile = file
                    val filename = BackupRules.filename(english)
                    try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, filename), EXPORT_FILE) }
                    catch (_: Exception) { finishExport(false) }
                }
            } catch (_: Exception) { runOnUiThread { exportBusy = false; sendError(text("Yedek oluşturulamadı.", "Could not create the backup."), id); exportId = null } }
        }
    }
    private fun finishExport(success: Boolean, cancelled: Boolean = false) {
        val id = exportId; exportFile?.delete(); exportFile = null; exportId = null; exportBusy = false
        val response = JSONObject().put("type", if (success) "exported" else if (cancelled) "exportCancelled" else "error")
        if (id != null) response.put("requestID", id)
        if (!success && !cancelled) response.put("message", text("Yedek kaydedilemedi; tekrar dene.", "The backup could not be saved. Please try again."))
        deliver(response)
    }
    private fun importFile() {
        if (exportId != null || exportBusy || importing) return
        try { importing = true; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream")), IMPORT_FILE) }
        catch (_: Exception) { importing = false; sendError(text("Dosya seçici açılamadı.", "The file picker could not be opened.")) }
    }
    @Deprecated("Uses the platform document picker contract")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == EXPORT_FILE) {
            if (resultCode != RESULT_OK || uri == null) { finishExport(false, cancelled = true); return }
            val file = exportFile
            exportBusy = true
            io.execute {
                val success = try {
                    require(file?.exists() == true)
                    contentResolver.openOutputStream(uri, "wt")?.use { out -> file!!.inputStream().use { it.copyTo(out) }; out.flush() } ?: error("No output stream")
                    true
                } catch (_: Exception) { false }
                runOnUiThread { finishExport(success) }
            }
        } else if (requestCode == IMPORT_FILE) {
            if (resultCode != RESULT_OK || uri == null) { importing = false; return }
            val pageGeneration = generation
            io.execute {
                try {
                    val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytesBounded(MAX_BACKUP) } ?: error("No input stream")
                    val payload = JSONObject(bytes.toString(Charsets.UTF_8))
                    require(payload.optString("application") == "Hesap" && payload.optInt("version") in 1..3)
                    runOnUiThread { importing = false; if (generation == pageGeneration) deliver(JSONObject().put("type", "import").put("payload", payload)) }
                } catch (_: Exception) { runOnUiThread { importing = false; sendError(text("Dosya okunamadı; geçerli bir Hesap yedeği seç.", "The file could not be read. Select a valid Hesap backup.")) } }
            }
        }
    }
    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putString("exportId", exportId); out.putString("exportPath", exportFile?.absolutePath)
        out.putBoolean("importing", importing); out.putString("pendingNotice", pendingNotice)
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); pendingNotice = intent.getStringExtra("noticeId"); openPendingNotice() }
    private fun openPendingNotice() { if (!ready) return; val id = pendingNotice ?: return; pendingNotice = null; deliver(JSONObject().put("type", "openNotification").put("id", id)) }
    override fun onResume() { super.onResume(); if (::web.isInitialized) { web.onResume(); if (ready) web.evaluateJavascript("window.Hesap?.refreshRates();window.Hesap?.refreshNotifications(undefined,true);", null) } }
    override fun onPause() { if (::web.isInitialized) web.onPause(); super.onPause() }
    private fun handleBack() {
        if (dateDialog?.isShowing == true) { dateDialog?.dismiss(); return }
        if (!ready) { finish(); return }
        web.evaluateJavascript("window.HesapAndroidBack?.()") { handled -> if (handled != "true") finish() }
    }
    override fun onDestroy() { dateDialog?.dismiss(); if (::web.isInitialized) { ready = false; web.destroy() }; io.shutdown(); super.onDestroy() }
    companion object { const val APP_ORIGIN = "https://appassets.androidplatform.net"; const val APP_URL = "$APP_ORIGIN/assets/finans-ilk-prototip.html"; const val MAX_BACKUP = 20 * 1024 * 1024; const val EXPORT_FILE = 100; const val IMPORT_FILE = 101; const val PERMISSION_NOTIFICATIONS = 102 }
}
