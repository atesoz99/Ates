package com.ates.hesap

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object BackupRules {
    fun filename(english: Boolean, at: Date = Date()): String {
        val formatter = SimpleDateFormat("dd-MM-yyyy", Locale.US).apply { timeZone = TimeZone.getTimeZone("Europe/Istanbul") }
        return (if (english) "My Hesap Data" else "Hesap Verilerim") + " " + formatter.format(at) + ".json"
    }
}
object DateRules {
    fun parse(value: String): Long? {
        if (!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return null
        return try { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(value)?.time } catch (_: Exception) { null }
    }
    fun bounds(field: String, at: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val today = Calendar.getInstance().apply { timeInMillis = at; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val min = if (field == "term-end") (today.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis else parse("1900-01-01")!!
        val max = if (field == "term-end") parse("2100-12-31")!! else today.timeInMillis
        return min to max
    }
}
fun InputStream.readBytesBounded(limit: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) { val n = read(buffer); if (n < 0) break; require(out.size() + n <= limit) { "File too large" }; out.write(buffer, 0, n) }
    return out.toByteArray()
}

fun nextYearlyReminder(at: Long, now: Long): Long {
    val current = Calendar.getInstance().apply { timeInMillis = now }
    val occurrence = Calendar.getInstance().apply { timeInMillis = at; set(Calendar.YEAR, current.get(Calendar.YEAR)) }
    if (occurrence.timeInMillis <= now) occurrence.add(Calendar.YEAR, 1)
    return occurrence.timeInMillis
}
