# Android v112 — 17 Kasım 2026

- Son ortak v112 HTML dosyası APK içinde birebir doğrulandı.
- Debug APK derlemesi, beş yerel JUnit testi ve Android Lint geçti; lint hata yok, önceki uyarılar sürüyor.
- Sıfırlama sonrası eski 1 Ekim bildirimi, eski başlangıç kaydının geçişi, web/native sıfırlama onayı, yeniden açılış, ilk kurulum karşılama bildirimi, gelecekteki yedekleme hatırlatması ve depolama hatasında geri alma Chromium/WebKit üzerinde kontrol edildi.
- Native Android kodu v111 ile aynıdır; versionName 1.1, versionCode 3.
- Fiziksel Android telefon testi yapılmadı. Önceki v111 emülatör testinde sistem servislerinde ve uygulamanın ilk açılışında ANR görüldüğü için cihaz testleri geçmiş sayılmadı. v112 cihaz üzerinde ayrıca kontrol edilmelidir.

Kaynak ZIP Android Studio'da HesapAndroid klasörü seçilerek açılır. local.properties ve özel imzalama anahtarları dahil değildir. Test APK'sı Google Play dosyası değildir. Telefonda farklı imza varsa uygulamayı kaldırmak yerine kendi Android Studio projenizden güncelleyin.
