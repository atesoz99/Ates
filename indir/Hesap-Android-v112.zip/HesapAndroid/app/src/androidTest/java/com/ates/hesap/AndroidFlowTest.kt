package com.ates.hesap

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class AndroidFlowTest {
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun findWeb(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) findWeb(view.getChildAt(i))?.let { return it }
        return null
    }
    private fun eval(script: String): String {
        val latch = CountDownLatch(1); var result = ""
        scenario.onActivity { a -> findWeb(a.window.decorView)!!.evaluateJavascript(script) { result = it; latch.countDown() } }
        assertTrue("JS callback timed out", latch.await(15, TimeUnit.SECONDS))
        return result
    }
    private fun awaitJs(script: String) {
        val end = System.currentTimeMillis() + 30000
        while (System.currentTimeMillis() < end) { if (eval(script) == "true") return; Thread.sleep(150) }
        fail("Condition did not become true: $script")
    }
    @Test fun bundledAppPaymentDatePickerAndNativeBack() {
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            awaitJs("!!window.Hesap && document.getElementById('home').classList.contains('active')")
            assertEquals("true", eval("isSecureContext && !!window.crypto.randomUUID && !!window.webkit.messageHandlers.hesap"))
            val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
            for (screen in listOf("trade", "track", "term", "charts", "more", "home")) {
                eval("document.querySelector('[data-tab=\"$screen\"]').click()")
                awaitJs("document.getElementById('$screen').classList.contains('active') && window.scrollY===0")
            }
            eval("document.querySelector('[data-tab=\"charts\"]').click();document.getElementById('charts-info-open').click()")
            awaitJs("!document.getElementById('charts-info-overlay').hidden")
            device.pressBack()
            awaitJs("document.getElementById('charts-info-overlay').hidden && document.getElementById('charts').classList.contains('active')")
            eval("document.querySelector('[data-tab=\"trade\"]').click();document.getElementById('asset').value='Gram altın';document.getElementById('asset').dispatchEvent(new Event('change'));document.getElementById('gold-conversion-info-open').click()")
            awaitJs("!document.getElementById('gold-conversion-info-overlay').hidden")
            eval("document.getElementById('gold-conversion-kind').value='republic';document.getElementById('gold-conversion-kind').dispatchEvent(new Event('change'));document.getElementById('gold-conversion-amount').value='2';document.getElementById('gold-conversion-amount').dispatchEvent(new Event('input'))")
            awaitJs("document.getElementById('gold-conversion-result').textContent==='13,22'")
            device.pressBack()
            awaitJs("document.getElementById('gold-conversion-info-overlay').hidden && document.getElementById('trade').classList.contains('active')")
            eval("document.querySelector('[data-tab=\"more\"]').click();document.getElementById('new-payment-open').click();document.getElementById('rec-name').value='Android smoke';document.getElementById('rec-day').value='10';document.getElementById('rec-amount').value='100';document.getElementById('recurring-form').requestSubmit()")
            awaitJs("document.getElementById('rec-list').textContent.includes('Android smoke')")
            eval("document.querySelector('[data-tab=\"term\"]').click();document.getElementById('new-term-open').click();document.getElementById('term-start-picker').click()")
            assertTrue("Native date picker absent", device.wait(Until.hasObject(By.clazz("android.widget.DatePicker")), 15000))
            device.pressBack()
            awaitJs("!document.getElementById('term-entry-overlay').hidden")
            device.pressBack()
            awaitJs("document.getElementById('term-entry-overlay').hidden && !document.body.classList.contains('modal-open')")
            eval("document.querySelector('[data-tab=\"more\"]').click();document.getElementById('account-open').click();document.getElementById('backup-export').click()")
            assertTrue("System backup picker absent", device.wait(Until.hasObject(By.pkg("com.google.android.documentsui")), 15000) || device.hasObject(By.pkg("com.android.documentsui")))
            device.pressBack()
            awaitJs("JSON.parse(localStorage.getItem('finansim-prototype-v1')).recurring.some(x=>x.name==='Android smoke')")
        } finally { scenario.close() }
    }
    @Test fun latestPastDepositToggleAndCapitalLinks() {
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            awaitJs("!!window.Hesap")
            eval("(()=>{const k='finansim-prototype-v1',d=JSON.parse(localStorage.getItem(k));d.autoDeleteMaturedTerms=false;d.terms=[{id:'android-past-1',start:'2020-01-01',tryEnd:'2020-02-01',principal:1000,income:100,startFx:40,endFx:50},{id:'android-past-2',start:'2020-01-01',tryEnd:'2020-03-01',principal:2000,income:200,startFx:40,endFx:50}];localStorage.setItem(k,JSON.stringify(d));location.reload()})()")
            awaitJs("!!window.Hesap && !!document.querySelector('#past-terms-show-all')")
            eval("document.querySelector('[data-tab=\"term\"]').click()")
            awaitJs("document.querySelectorAll('#past-terms [data-term-card]').length===1")
            eval("document.getElementById('past-terms-show-all').click()")
            awaitJs("document.querySelectorAll('#past-terms [data-term-card]').length===2 && document.getElementById('past-terms-show-all').getAttribute('aria-expanded')==='true'")
            assertEquals("true",eval("document.getElementById('past-terms-show-all').closest('.past-terms-footer').previousElementSibling.dataset.termCard==='android-past-2'"))
            eval("document.getElementById('past-terms-show-all').click()")
            awaitJs("document.querySelectorAll('#past-terms [data-term-card]').length===1")
            eval("document.querySelector('[data-tab=\"home\"]').click();document.getElementById('home-capital-update').click()")
            awaitJs("document.getElementById('track').classList.contains('active') && !document.getElementById('current-capital-panel').hidden")
            assertEquals("true",eval("Math.abs(document.getElementById('annual-income').closest('.summary').getBoundingClientRect().top-(parseFloat(getComputedStyle(document.querySelector('.app')).paddingTop)+22))<2"))
            eval("document.getElementById('capital-form-heading').click()")
            awaitJs("!document.getElementById('capital-form').hidden")
            assertEquals("true",eval("Math.abs(document.getElementById('annual-income').closest('.summary').getBoundingClientRect().top-(parseFloat(getComputedStyle(document.querySelector('.app')).paddingTop)+1))<2"))
            eval("window.Hesap.openNotification('monthly-2026-11-01')")
            awaitJs("!document.getElementById('capital-form').hidden && document.getElementById('track').classList.contains('active')")
        } finally { scenario.close() }
    }

}
