import SwiftUI

@main struct MyApp: App {
    @UIApplicationDelegateAdaptor(HesapAppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
