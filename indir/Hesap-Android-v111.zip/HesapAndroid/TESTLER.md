# Android v111 kontrolleri — 16 Kasım 2026

Ortak HTML SHA-256: `4af32bbb526c70a7e1ac81fc64deffff4758c9a0ca2e347f0475f9681f2264a3`

- Kaynak HTML, son v111 prototipi ve derlenmiş APK/AAB içindeki HTML birebir eşleştirildi.
- Debug APK ve release AAB derlemesi başarılı. Release AAB için kendi yükleme anahtarınızla imzalama gerekir.
- Beş yerel JUnit testi geçti: finans kuralları ve tekrarlı yedekleme hatırlatmaları.
- Android Lint: hata yok; mevcut sekiz uyarı (SharedPreferences, simge ve kullanılmayan kaynak bildirimleri).
- Android köprüsü Chromium üzerinde Türkçe/İngilizce, üç ekran genişliği ve altı sekmede kontrol edildi. Yeni altın ve grafik bilgi pencereleri geri tuşuyla kapanıyor; altın hesaplayıcı ve yerel tarih seçici mesajları çalışıyor. Taşma veya JavaScript hatası görülmedi.
- Android 15 emülatörüne APK ve test paketi kuruldu. Emülatörde Android sistem servislerinde ANR hataları ve test çalıştırıcısında "Process crashed" sonucu oluştu; cihaz üzerindeki akış testleri tamamlanmış sayılmadı. Bu sonuç, fiziksel telefon testi yerine kullanılmadı.

Fiziksel Android telefon testi bu ortamda yapılmadı. Emülatör donanım hızlandırması olmadan çalıştığından emülatör süreleri telefon performansı ölçümü olarak kullanılmadı.

## Dosyalar
- HesapAndroid: Android Studio ile açılacak tam kaynak proje.
- Test APK'sı: geliştirme imzalıdır; Google Play'e yükleme dosyası değildir. Mevcut telefon kurulumunun imzası farklıysa Android Studio'daki kendi projenizi Run ile güncelleyin. Verileri korumak için uygulamayı kaldırmayın.
- local.properties, SDK, .gradle, build klasörleri ve özel imzalama dosyaları kaynak ZIP'e alınmaz.
