# Hesap — Android projesi

Bu klasör Android Studio ile açılabilen tam projedir. Son v152 finans prototipini, seçilebilir karşılaştırma/vade birimlerini ve güncel Al-Sat açılış konumunu içerir. Android tarafına dosya yedekleme/geri yükleme, tarih seçimi, bildirimler, geri tuşu ve harcama hedefi widget'ı eklenmiştir. iPhone projeniz değişmez.

## Mac'te açılış

1. ZIP'i açın.
2. Android Studio'da File → Open ile **HesapAndroid** klasörünü seçin. Bu klasörde `settings.gradle.kts` bulunur. Önceden oluşturduğunuz boş projeye dosya yapıştırmanız gerekmez.
3. Gradle eşitlemesi ve SDK indirmeleri tamamlanana kadar bekleyin. Gradle JDK olarak Android Studio'nun yerleşik JDK 21 sürümünü kullanabilirsiniz. Proje SDK 36 ister.
4. Üstte Android telefonunuzu veya emülatörü seçip yeşil Run düğmesine basın.

Paket: com.ates.hesap · Sürüm: 1.2.1 · Android versionCode: 5 · Minimum: Android 7.0 (API 24) · Hedef: API 36. Android versionCode, iOS build numarasından bağımsızdır.

## Telefonda birlikte kontrol edilecekler

- Türkçe/İngilizce, açık/koyu tema ve tüm sekmeler.
- Alış/satış, sıfıra inen eldeki miktar, geçmiş işlem silme ve ortalama hesaplaması.
- Aylık kayıt, negatif ana para ve ana sayfadaki ilgili form bağlantıları.
- Vade ve ödeme ekleme/düzenleme/silme, tarih seçimi ve Android geri tuşu.
- Kur yenileme; çevrimdışı açılış ve bağlantı geri geldiğinde yenileme.
- Yedek dosyasını kaydetme, iptal etme ve geri yükleme. Önce deneme verileriyle sınayın.
- Bildirim izni verme/reddetme ve yaklaşan ödeme/vade bildirimi.
- Klavye açıldığında form alanları ve alt menü; küçük ekran ve büyük yazı ayarları.

Android'deki kayıtlar iPhone'dan otomatik taşınmaz. JSON yedek dosyasıyla aktarılabilir. Kayıtlar cihazda tutulur. Uygulamayı kaldırmak yerel verileri siler; önce yedek alın.

Android, pil tasarrufu/uyku koşullarında yerel bildirimleri geciktirebilir. Uygulamayı zorla durdurmak bildirimleri yeniden açılana kadar engelleyebilir.

## Google Play dosyası

Gerçek telefon kontrolünden sonra Build → Generate Signed App Bundle / APK → Android App Bundle yolunu kullanın. Kendi yükleme anahtarınızı oluşturun ve güvenli biçimde yedekleyin. Anahtar/parolalar bu projeye eklenmemiştir; kimseyle paylaşmayın. Test APK'sı Google Play'e yüklenmez; imzalı AAB hazırlanır.

Bu paket, Google Play gönderimi veya onayı anlamına gelmez. Play Console kimlik/telefon doğrulaması, test ve mağaza gereklilikleri ayrıca tamamlanır.

## Geliştirici kontrolleri

`./gradlew :app:assembleDebug :app:bundleRelease :app:testDebugUnitTest :app:lintDebug`

Cihaz bağlıyken: `./gradlew :app:connectedDebugAndroidTest`

Release imzalama bilgisi özellikle eklenmemiştir. `local.properties` makineye özgüdür; Android Studio kendi SDK yolunu oluşturur.

## Android kenar boşluğu düzeltmesi (2)

Sistem çubuklarının boşluğu yalnızca yerel Android görünümünde uygulanır. WebView içinde ikinci kez uygulanan safe-area boşlukları Android sunumunda sıfırlanır. Orijinal HTML dosyası, yazı boyutları, kart genişlikleri ve finans hesaplamaları değiştirilmez. Mevcut uygulamayı telefondan kaldırmadan aynı paket üzerinden Run ile güncelleyin.

## Android simge ve açılış düzeltmesi (3)

Yalnızca Android sunumunda Varlık ve Vade simgeleri 23px, Ödemeler simgesi 17px yapılmıştır; 22px satır kutuları, menü konumu ve etiketler korunur. Android 12 ve sonrasında sistem açılış ekranının arka planı açıkça #181a1e tanımlanır; eski Android sürümlerinin pencere arka planı ve koyu yerel görünüm de aynı renktedir. iOS ve orijinal finans HTML dosyası değiştirilmemiştir.

## Android seçim penceresi teması (4)

WebView, uygulamanın seçili temasına ait ContextThemeWrapper ile oluşturulur. Android sistem seçim pencereleri koyu/açık temanın arka planı, metin ve vurgu renklerini kullanır. Tema değişimi aynı WebView bağlamına uygulanır; sayfa yeniden yüklenmez. Telefon üreticisi ve Android System WebView sürümü pencerenin biçimini belirlemeye devam eder.

## Açılış simgesi netliği (5)

Android 8 ve sonrası adaptive icon ön planı, 192px bitmap yerine orijinal 1024x1024 PNG dosyasını drawable-nodpi kaynağından kullanır. Android 12 açılış simgesi de aynı adaptive icon kaynağını kullanır. Orijinal görsel, mevcut maske, yüzde 16 iç boşluk, arka plan ve sistemin belirlediği açılış boyutu korunur.

## Mavi açılış arka planı (6)

Açılış arka planı, Tüm Portföy Değeri kartının mavisi olan #303f52 olarak güncellenmiştir. Android 12+ splash ve eski sürümlerin pencere arka planı aynı kaynağı kullanır. Uygulama açıldıktan sonra durum ve gezinme çubukları seçili uygulama temasına döner. 1024px simge korunur.

## iPhone biçiminde açılış (7)

Açılışta adaptive launcher simgesi yerine şeffaf zeminli beyaz vektör H/halka logosu kullanılır. Mavi #304660, gönderilen iPhone projesinin HesapLaunchBackground rengidir. Android sisteminin güvenli simge alanı içinde kalacak boşluk eklenmiştir. Android 12+ sistem splash ekranı ve eski sürümlerdeki pencere arka planı bu logoyu kullanır. Ana ekrandaki uygulama simgesi değişmez.

## Ortak v275 güncellemesi

Paket kökündeki OKU.md ve TESTLER.md dosyaları son değişiklikleri açıklar. Yukarıdaki v274 notları önceki Android uyarlamalarına aittir.

## v276 kredi kartı hatırlatmaları

Üçüncü ödeme türü: Kredi Kartı. Ad, son ödeme günü ve hesap kesim günü tutulur; 1–10 bağımsız kart desteklenir. Kartların tutarı yoktur. Yedek sürümü 3, Android içe aktarma desteği 1–3 olarak güncellenmiştir.

## v277 isteğe bağlı hafta sonu ayarı

Menüde otomatik vade silme ayarının altında, varsayılanı kapalı olan kredi kartı hafta sonu seçeneği eklenmiştir. Cumartesi/pazar son ödeme tarihleri pazartesiye taşınır. Liste, sıralama, takvim ve bildirimler aynı hesaplanan tarihi kullanır.

## Güncel prototip v112 — 16 Kasım 2026

- Ortak HTML dosyası son v112 ile aynıdır. Altın gram hesaplayıcısı, bilgi ve gizlilik metinleri, geçmiş vadeler, Tümünü Gör / Daha Az Göster, güncel ana paranın kesintisiz yenilenmesi ve son açılış konumları dahildir.
- Android geri tuşu, yeni Grafiklerim ve altın hesaplayıcı bilgi pencerelerini de kapatır.
- Otomatik vade silme yeni kullanıcıda kapalı başlar. Mevcut ayarlar ve yerel kayıtlar korunur.
- Android paket kimliği com.ates.hesap korunmuştur. versionName 1.1, versionCode 3. Google Play'de daha yüksek versionCode yüklediyseniz bundan daha büyük bir sayı kullanın.
- Makineye özel local.properties, derleme önbellekleri ve imzalama anahtarları teslim ZIP'ine alınmaz. Android Studio SDK yolunu kendi bilgisayarınızda oluşturur.

## v112 bildirim sıfırlama düzeltmesi
Verileri sil işleminde bildirim geçmişi için yeni başlangıç zamanı kaydedilir. Başlangıç tarihi eksik eski kayıtlardan geçmiş yedekleme hatırlatmaları yeniden oluşturulmaz. Gelecekteki bildirimler korunur.

## Son prototip — v150 (20 Kasım 2026)

- Prototipteki para birimi seçimi, bağımsız vade birimi, güncel yazılar, yazı boyutları ve boşluklar bu pakettedir.
- Altın/gümüş alış ortalaması için bağımsız ons alış fiyatı seçeneği ve kayıtlı tercih desteği vardır.
- Al-Sat bağlantıları kutunun altını alt menüden 32 px yukarıda açar.
- Karşılaştırma birimi penceresi Android geri tuşuyla kapanır.
- Mevcut uygulamayı kendi Android Studio projeniz ve aynı imza anahtarınızla güncelleyin. Uygulama kimliği `com.ates.hesap` olarak korunmuştur.
- Bu paketteki test APK’sı geliştirme imzalıdır. Önceki test APK’sı farklı anahtarla imzalandıysa doğrudan üzerine kurulamaz. Kayıtları korumak için uygulamayı kaldırmadan önce JSON yedeğinizi alın; tercihen mevcut kendi projenizden aynı anahtarla güncelleyin.

## Bu paketi sıfırdan açma — v152

1. ZIP'i açın ve HesapAndroid klasörünü İndirilenler dışında kalıcı bir yere, örneğin Belgeler/HesapAndroid içine taşıyın.
2. Android Studio açılış ekranında Open seçin; içinde settings.gradle.kts bulunan HesapAndroid klasörünü açın. Eski Recent Projects kısayolunu seçmeyin.
3. Gradle Sync'in bitmesini bekleyin. JDK olarak Android Studio'nun Embedded JDK 21 sürümünü seçin.
4. Telefonu bağlayıp app yapılandırmasında Run düğmesine basın.

Son v152 HTML dosyası hazır şekilde pakettedir; ayrıca dosya değiştirmeniz gerekmez. Dolar ve Gram altın seçildiğinde ons karşılaştırma satırı gizlenir, yerleşim korunur. Al-Sat açılışının alt menüye uzaklığı 29 px olarak günceldir.
