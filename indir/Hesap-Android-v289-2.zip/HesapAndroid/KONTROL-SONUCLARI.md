# Kontrol sonuçları — Android / HTML v289

- Paket adı: com.ates.hesap
- Android versionName: 1.0; versionCode: 1
- Minimum SDK 24, target/compile SDK 36
- assembleDebug: BAŞARILI
- bundleRelease: BAŞARILI (imzasız AAB; mağaza gönderimi yapılmadı)
- testDebugUnitTest: 3 test, 0 başarısız
- lintDebug: 0 hata; 20 uyarı (kaynak/simge, tercih yazımı ve Kotlin önerileri)
- Tarayıcıdaki Android köprü testi: köprü başlangıcı, iç içe Dönemsel bilgi pencereleri, karşılaştırma/altın/diğer info pencerelerinde geri davranışı, yerel tarih mesajı ve tarih dönüşü, yedek dışa aktarma isteği ve dil mesajları geçti.
- HTML dosyası son v289 ile birebir aynı; bu dosyanın önceki toplu finans/çeviri kontrolleri korunuyor.
- Android fiziksel cihaz/emülatör testi ÇALIŞTIRILMADI: ortamda bağlı cihaz yok. Sistem dosya seçici, gerçek bildirim teslimi, klavye, üretici WebView farkları ve kaydırma akıcılığı telefonda doğrulanmalıdır.

HTML SHA-256: 15c992ab55feab11bd3c71d01ba2df01d1379451ecc04bb723e76d80c3c153ec

Android v289-1 ek kontrolü: üç ekran genişliğinde ana/toplam/dönemsel/kısaltmalı Ons tutarları ve yüzdeleri tam 1px küçüldü; başlıklar ve kutu genişlikleri korunuyor. assembleDebug, testDebugUnitTest ve lintDebug başarılı. Orijinal finans HTML dosyası değiştirilmedi.

v289-2: üç ekran genişliğinde 22 hedef değer 16px -> 15px doğrulandı; 10 başlık/diğer değer değişmedi. assembleDebug, testDebugUnitTest ve lintDebug başarılı. Finans HTML dosyası aynı.
