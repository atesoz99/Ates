# Son sürüm hareket ve performans incelemesi

6 Kasım 2026. Başlangıç sürümü v201; düzeltilen sürüm v202.

## Tespit edilen ve giderilen durumlar

- Aynı içerikteki kartlar, kayıt listeleri ve grafikler fiyat güncellemelerinde yeniden oluşturuluyordu. Görünüm değişmediyse mevcut elemanlar korunur. Varlık ve grafik yıl seçicilerindeki seçenekler de gereksiz yere yenilenmez.
- Tam metin taraması ve hizalama hesapları, aynı dildeki küçük güncellemelerde ve görünmeyen bölümlerde tekrarlanıyordu. Tam dil taraması başlangıçta/dil değişiminde yapılır; normal güncellemede değişen alanlar işlenir. Hizalama, görünür panelin içeriği veya genişliği değiştiğinde çalışır.
- Uygulama odağı kaybederken touchend gelmezse dokunma durumu açık kalıp canlı çizimleri bekletebilirdi. Odak/görünürlük geçişinde bu durum temizlenir.

Görünüm tasarımı, hesap formülleri ve kayıt biçimi değiştirilmedi. Swift dosyaları incelendi; bu tur değiştirilmedi.

## Ölçüm

Chromium mobil görünümü, 393×852, işlemci 4 kat yavaşlatılmış durumda. 590 alış-satış, 59 aylık ana para ve bütçe kaydı, 40 ödeme, 15 vade içeren yoğun kayıt örneği kullanıldı. Her ekranda beş yenilemenin ortanca süresi:

| Ekran | Önce | Sonra |
| --- | --- | --- |
| Ana Sayfa | 130 ms | 74 ms |
| Varlık | 172 ms | 65 ms |
| Takip | 139 ms | 89 ms |
| Vade | 117 ms | 75 ms |
| Grafiklerim | 190 ms | 84 ms |
| Ödemeler | 127 ms | 97 ms |

Bu altı ortanca sürenin ortalaması yaklaşık 146 ms'den 81 ms'ye indi; bu senaryoda yaklaşık %45 kısalma. Bunlar laboratuvar tarayıcı ölçümleridir, iPhone ölçümü değildir.

## Geçen kontroller

- Altı sekmede hızlı geçişler ve en üste açılma.
- Ana sayfa Portföyüm, aylık kayıt, güncel ana para ve ödeme bağlantılarında ilk konumun sabit kalması.
- Kare kare kaydırma sırasında canlı güncelleme, kaydırmanın geri alınmaması ve durduktan sonra konumun korunması.
- Menü/açılır ekran kaydırması ve kapatınca alttaki sayfanın konumuna dönme.
- Odak kaybında yarım kalan dokunma hareketinden kurtulma.
- Güncelleme sırasında formdaki miktar ve yazı odağının korunması.
- Türkçe-İngilizce-Türkçe geçişi, 320 ve 393 piksel genişlikler; yatay sayfa taşması gözlenmedi.
- Altı ekranda değişiklik öncesi/sonrası metin ve grafik SVG çıktılarının eşitliği.
- Ons günlük görünüm tercihi, canlı fiyatın alternatif kaynaktan alınması, çevrimdışı eski fiyatın korunması ve eksik ons verisi.
- Çoklu TL yatırımı, yedekleme/geri yükleme/sıfırlama iptal ve onay akışları, ödeme bildirimi yönlendirmesi ve takvim olayları.
- Günlük hesapların mevcut aritmetik testleri.

Test edilen akışlarda JavaScript sayfa hatası görülmedi.

## Sınırlar

Fiziksel iPhone, iOS klavyesi ve gerçek WKWebView performansı bu Linux ortamında çalıştırılamadı. WebKit testi için tarayıcı indirildi ancak gerekli sistem kütüphaneleri mevcut olmadığından çalıştırılamadı. Xcode derlemesi yapılmadı; Swift değişmedi. Bu inceleme sıfır hata garantisi vermez; son cihaz denemesinde özellikle klavyeyi kapatıp hemen kaydırma ve uygulamayı arka plandan geri açma kontrol edilmelidir.
