# Android v150 — 20 Kasım 2026

- APK içindeki finans HTML dosyasının v150 prototipiyle bayt düzeyinde aynı olduğu SHA-256 ile doğrulandı.
- Debug APK ve Android cihaz test paketi derlemeleri geçti.
- Beş yerel JUnit testi geçti (0 hata, 0 başarısız test).
- Android Lint geçti; hata yok. Mevcut uyarılar raporda sürüyor.
- Android köprüsü ve Android sunumu Chromium üzerinde 320, 393 ve 430 px genişliklerde kontrol edildi: tüm sekmeler, karşılaştırma seçimi ve saklanması, karşılaştırma penceresini geri tuşuyla kapatma, native tarih seçme isteği, altın için manuel ons alanı ve vade formunun sabit boyutu.
- Android cihaz test kodu güncel manuel sekme davranışı ve karşılaştırma penceresi için güncellendi; bu ortamda fiziksel Android telefon veya emülatör testi çalıştırılmadı. Cihaz testi geçmiş sayılmamıştır.

## Cihazda kalan kontroller

Kendi cihazınızda JSON yedekleme/geri yükleme, gerçek sistem tarih seçicisi, bildirim izni ve teslimi, widget, klavye ve canlı kurlar kontrol edilmelidir.

Paket: com.ates.hesap · versionName 1.2 · versionCode 4.

Kaynak ZIP içinde local.properties, derleme önbelleği ve özel imzalama anahtarı yoktur. Test APK'sı Google Play dosyası değildir. Farklı imza nedeniyle kurulum güncellemesi reddedilirse kayıtları korumak için kendi projeniz ve önceki imzanızla güncelleyin.
