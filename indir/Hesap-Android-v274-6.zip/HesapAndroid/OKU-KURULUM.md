# Hesap — Android projesi

Bu klasör Android Studio ile açılabilen tam projedir. Gönderdiğiniz Xcode projesindeki v274 finans HTML dosyası değiştirilmeden kullanılmıştır. Android tarafına dosya yedekleme/geri yükleme, tarih seçimi, bildirimler, geri tuşu ve harcama hedefi widget'ı eklenmiştir. iPhone projeniz değişmez.

## Mac'te açılış

1. ZIP'i açın.
2. Android Studio'da File → Open ile **HesapAndroid** klasörünü seçin. Bu klasörde `settings.gradle.kts` bulunur. Önceden oluşturduğunuz boş projeye dosya yapıştırmanız gerekmez.
3. Gradle eşitlemesi ve SDK indirmeleri tamamlanana kadar bekleyin. Gradle JDK olarak Android Studio'nun yerleşik JDK 21 sürümünü kullanabilirsiniz. Proje SDK 36 ister.
4. Üstte Android telefonunuzu veya emülatörü seçip yeşil Run düğmesine basın.

Paket: com.ates.hesap · Sürüm: 1.0 · Android versionCode: 1 · Minimum: Android 7.0 (API 24) · Hedef: API 36. Android versionCode, iOS build numarasından bağımsızdır.

## Telefonda birlikte kontrol edilecekler

- Türkçe/İngilizce, açık/koyu tema ve tüm sekmeler.
- Alış/satış, sıfıra inen eldeki miktar, geçmiş işlem silme ve ortalama hesaplaması.
- Aylık kayıt, negatif ana para ve ana sayfadaki ilgili form bağlantıları.
- Vade ve ödeme ekleme/düzenleme/silme, tarih seçimi ve Android geri tuşu.
- Kur yenileme; çevrimdışı açılış ve bağlantı geri geldiğinde yenileme.
- Yedek dosyasını kaydetme, iptal etme ve geri yükleme. Önce deneme verileriyle sınayın.
- Bildirim izni verme/reddetme ve yaklaşan ödeme/vade bildirimi.
- Klavye açıldığında form alanları ve alt menü; küçük ekran ve büyük yazı ayarları.

Android'deki kayıtlar iPhone'dan otomatik taşınmaz. JSON yedek dosyasıyla aktarılabilir. Kayıtlar cihazda tutulur. Uygulamayı kaldırmak yerel verileri siler; önce yedek alın.

Android, pil tasarrufu/uyku koşullarında yerel bildirimleri geciktirebilir. Uygulamayı zorla durdurmak bildirimleri yeniden açılana kadar engelleyebilir.

## Google Play dosyası

Gerçek telefon kontrolünden sonra Build → Generate Signed App Bundle / APK → Android App Bundle yolunu kullanın. Kendi yükleme anahtarınızı oluşturun ve güvenli biçimde yedekleyin. Anahtar/parolalar bu projeye eklenmemiştir; kimseyle paylaşmayın. Test APK'sı Google Play'e yüklenmez; imzalı AAB hazırlanır.

Bu paket, Google Play gönderimi veya onayı anlamına gelmez. Play Console kimlik/telefon doğrulaması, test ve mağaza gereklilikleri ayrıca tamamlanır.

## Geliştirici kontrolleri

`./gradlew :app:assembleDebug :app:bundleRelease :app:testDebugUnitTest :app:lintDebug`

Cihaz bağlıyken: `./gradlew :app:connectedDebugAndroidTest`

Release imzalama bilgisi özellikle eklenmemiştir. `local.properties` makineye özgüdür; Android Studio kendi SDK yolunu oluşturur.

## Android kenar boşluğu düzeltmesi (2)

Sistem çubuklarının boşluğu yalnızca yerel Android görünümünde uygulanır. WebView içinde ikinci kez uygulanan safe-area boşlukları Android sunumunda sıfırlanır. Orijinal HTML dosyası, yazı boyutları, kart genişlikleri ve finans hesaplamaları değiştirilmez. Mevcut uygulamayı telefondan kaldırmadan aynı paket üzerinden Run ile güncelleyin.

## Android simge ve açılış düzeltmesi (3)

Yalnızca Android sunumunda Varlık ve Vade simgeleri 23px, Ödemeler simgesi 17px yapılmıştır; 22px satır kutuları, menü konumu ve etiketler korunur. Android 12 ve sonrasında sistem açılış ekranının arka planı açıkça #181a1e tanımlanır; eski Android sürümlerinin pencere arka planı ve koyu yerel görünüm de aynı renktedir. iOS ve orijinal finans HTML dosyası değiştirilmemiştir.

## Android seçim penceresi teması (4)

WebView, uygulamanın seçili temasına ait ContextThemeWrapper ile oluşturulur. Android sistem seçim pencereleri koyu/açık temanın arka planı, metin ve vurgu renklerini kullanır. Tema değişimi aynı WebView bağlamına uygulanır; sayfa yeniden yüklenmez. Telefon üreticisi ve Android System WebView sürümü pencerenin biçimini belirlemeye devam eder.

## Açılış simgesi netliği (5)

Android 8 ve sonrası adaptive icon ön planı, 192px bitmap yerine orijinal 1024x1024 PNG dosyasını drawable-nodpi kaynağından kullanır. Android 12 açılış simgesi de aynı adaptive icon kaynağını kullanır. Orijinal görsel, mevcut maske, yüzde 16 iç boşluk, arka plan ve sistemin belirlediği açılış boyutu korunur.

## Mavi açılış arka planı (6)

Açılış arka planı, Tüm Portföy Değeri kartının mavisi olan #303f52 olarak güncellenmiştir. Android 12+ splash ve eski sürümlerin pencere arka planı aynı kaynağı kullanır. Uygulama açıldıktan sonra durum ve gezinme çubukları seçili uygulama temasına döner. 1024px simge korunur.
