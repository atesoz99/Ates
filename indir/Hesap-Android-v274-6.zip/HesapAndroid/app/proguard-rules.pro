# No obfuscation in the initial release. Native bridge uses AndroidX origin checks.
