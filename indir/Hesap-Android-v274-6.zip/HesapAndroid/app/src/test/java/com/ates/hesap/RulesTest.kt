package com.ates.hesap

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.Date
import java.util.TimeZone

class RulesTest {
    @Test fun backupNamesUseIstanbulDateAndSelectedLanguage() {
        val instant = Date(1794160800000L) // 2026-11-08T18:00:00Z
        val tr = BackupRules.filename(false, instant)
        val en = BackupRules.filename(true, instant)
        assertTrue(tr.startsWith("Hesap Verilerim "))
        assertTrue(en.startsWith("My Hesap Data "))
        assertTrue(Regex(".* \\d{2}-\\d{2}-\\d{4}\\.json").matches(tr))
        assertFalse(tr.contains('/'))
        val oldZone = TimeZone.getDefault()
        try { TimeZone.setDefault(TimeZone.getTimeZone("America/Los_Angeles")); assertEquals(tr, BackupRules.filename(false, instant)) } finally { TimeZone.setDefault(oldZone) }
    }
    @Test fun fileReadLimitRejectsOversizeWithoutTruncatingValidFiles() {
        assertArrayEquals(byteArrayOf(1, 2, 3), ByteArrayInputStream(byteArrayOf(1, 2, 3)).readBytesBounded(3))
        try { ByteArrayInputStream(ByteArray(4)).readBytesBounded(3); fail("Oversized file accepted") } catch (_: IllegalArgumentException) {}
    }
    @Test fun invalidCalendarDatesAreRejectedAndMaturityStartsTomorrow() {
        assertNull(DateRules.parse("2026-02-30")); assertNull(DateRules.parse("2026-1-01"))
        val now = DateRules.parse("2026-11-09")!!
        assertEquals(now, DateRules.bounds("trade-date", now).second)
        assertEquals(DateRules.parse("2026-11-10"), DateRules.bounds("term-end", now).first)
        assertTrue(DateRules.bounds("term-end", now).second > now)
    }
}
