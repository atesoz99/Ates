package com.ates.hesap

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class SpendingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { updateAll(context) }
    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SpendingWidget::class.java))
            if (ids.isEmpty()) return
            val prefs = context.getSharedPreferences("hesap_native", Context.MODE_PRIVATE)
            val english = prefs.getString("language", "tr") == "en"
            val locale = if (english) Locale.UK else Locale.forLanguageTag("tr-TR")
            val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
            val goal = prefs.getFloat("dailyGoal", 0f).toDouble()
            val currency = NumberFormat.getCurrencyInstance(locale).apply { currency = java.util.Currency.getInstance("TRY"); maximumFractionDigits = 0 }
            val views = RemoteViews(context.packageName, R.layout.spending_widget)
            views.setTextViewText(R.id.widget_title, if (english) "Spending target to date" else "Bugüne kadarki harcama hedefi")
            views.setTextViewText(R.id.widget_amount, currency.format(goal * day))
            views.setTextViewText(R.id.widget_detail, if (english) "Day $day · Daily: ${currency.format(goal)}" else "Ayın $day. günü · Günlük: ${currency.format(goal)}")
            views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(ids, views)
        }
    }
}
