package com.ates.hesap

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

object MarketTransport {
    private val hosts = setOf("api.frankfurter.dev", "api.frankfurter.app", "finans.truncgil.com", "alyawmgold.com", "www.ecb.europa.eu")
    fun allowed(uri: Uri): Boolean = uri.scheme == "https" && uri.host in hosts && uri.userInfo == null && uri.port in listOf(-1, 443)
    private val cors get() = mutableMapOf("Access-Control-Allow-Origin" to MainActivity.APP_ORIGIN, "Access-Control-Expose-Headers" to "Retry-After,Cache-Control", "Cache-Control" to "no-store")
    fun error(code: Int, reason: String) = WebResourceResponse("text/plain", "UTF-8", code, reason, cors, ByteArrayInputStream(ByteArray(0)))
    fun fetch(initial: Uri): WebResourceResponse {
        var uri = initial
        repeat(5) {
            if (!allowed(uri)) return error(403, "Blocked")
            val connection = try { URL(uri.toString()).openConnection() as HttpURLConnection } catch (_: Exception) { return error(503, "Unavailable") }
            try {
                connection.connectTimeout = 10000; connection.readTimeout = 10000; connection.instanceFollowRedirects = false
                connection.setRequestProperty("Accept", "application/json,text/plain,application/xml")
                val code = connection.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    val redirect = connection.getHeaderField("Location") ?: return error(502, "Invalid redirect")
                    uri = Uri.parse(URL(URL(uri.toString()), redirect).toString())
                } else {
                    val bytes = (if (code in 200..299) connection.inputStream else connection.errorStream)?.use { stream -> stream.readBytesBounded(2 * 1024 * 1024) } ?: ByteArray(0)
                    val headers = cors
                    for (name in listOf("Retry-After", "Cache-Control")) connection.getHeaderField(name)?.let { value -> headers[name] = value }
                    val mime = connection.contentType?.substringBefore(';') ?: "application/json"
                    return WebResourceResponse(mime, "UTF-8", if (code in 100..599) code else 502, "Response", headers, ByteArrayInputStream(bytes))
                }
            } catch (_: Exception) { return error(503, "Unavailable") } finally { connection.disconnect() }
        }
        return error(502, "Redirect limit")
    }
}
