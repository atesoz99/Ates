(() => {
  'use strict';
  if (location.origin !== 'https://appassets.androidplatform.net' || window.top !== window) return;
  window.HesapNativeDatePicker = true;
  window.webkit = {messageHandlers: {hesap: {postMessage: message => AndroidHesap.postMessage(JSON.stringify(message))}}};
  // Theme messages and Android back handling do not change financial calculations or HTML layout.
  const sendTheme = () => window.webkit.messageHandlers.hesap.postMessage({action:'theme',dark:document.documentElement.dataset.theme==='dark'});
  new MutationObserver(sendTheme).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
  window.HesapAndroidBack = () => {
    const date=document.getElementById('payment-date-overlay');
    if(date && !date.hidden){document.getElementById('payment-date-cancel').click();return true;}
    for(const [overlay,close] of [['data-delete-confirm','data-delete-cancel'],['data-restore-confirm','data-restore-cancel'],['term-delete-confirm','term-delete-cancel'],['asset-info-overlay','asset-info-close'],['track-info-overlay','track-info-close'],['term-info-overlay','term-info-close'],['term-entry-overlay','term-entry-close'],['payment-entry-overlay','payment-entry-close'],['calendar-overlay','calendar-close'],['notifications-overlay','notifications-close'],['account-overlay','account-close']]){
      const el=document.getElementById(overlay),button=document.getElementById(close);
      if(el && !el.hidden && button && !button.disabled){button.click();return true;}
    }
    if(document.activeElement && ['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)){document.activeElement.blur();return true;}
    const home=document.querySelector('[data-tab="home"]');
    if(home && !document.getElementById('home').classList.contains('active')){home.click();return true;}
    return false;
  };
  addEventListener('DOMContentLoaded',()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{sendTheme();window.webkit.messageHandlers.hesap.postMessage({action:'ready'});})),{once:true});
})();
