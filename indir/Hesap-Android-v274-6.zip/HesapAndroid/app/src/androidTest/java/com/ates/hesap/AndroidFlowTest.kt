package com.ates.hesap

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class AndroidFlowTest {
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun findWeb(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) findWeb(view.getChildAt(i))?.let { return it }
        return null
    }
    private fun eval(script: String): String {
        val latch = CountDownLatch(1); var result = ""
        scenario.onActivity { a -> findWeb(a.window.decorView)!!.evaluateJavascript(script) { result = it; latch.countDown() } }
        assertTrue("JS callback timed out", latch.await(15, TimeUnit.SECONDS))
        return result
    }
    private fun awaitJs(script: String) {
        val end = System.currentTimeMillis() + 30000
        while (System.currentTimeMillis() < end) { if (eval(script) == "true") return; Thread.sleep(150) }
        fail("Condition did not become true: $script")
    }
    @Test fun bundledAppPaymentDatePickerAndNativeBack() {
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            awaitJs("!!window.Hesap && document.getElementById('home').classList.contains('active')")
            assertEquals("true", eval("isSecureContext && !!window.crypto.randomUUID && !!window.webkit.messageHandlers.hesap"))
            for (screen in listOf("trade", "track", "term", "charts", "more", "home")) {
                eval("document.querySelector('[data-tab=\"$screen\"]').click()")
                awaitJs("document.getElementById('$screen').classList.contains('active') && window.scrollY===0")
            }
            eval("document.querySelector('[data-tab=\"more\"]').click();document.getElementById('new-payment-open').click();document.getElementById('rec-name').value='Android smoke';document.getElementById('rec-day').value='10';document.getElementById('rec-amount').value='100';document.getElementById('recurring-form').requestSubmit()")
            awaitJs("document.getElementById('rec-list').textContent.includes('Android smoke')")
            val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
            eval("document.querySelector('[data-tab=\"term\"]').click();document.getElementById('new-term-open').click();document.getElementById('term-start-picker').click()")
            assertTrue("Native date picker absent", device.wait(Until.hasObject(By.clazz("android.widget.DatePicker")), 15000))
            device.pressBack()
            awaitJs("!document.getElementById('term-entry-overlay').hidden")
            device.pressBack()
            awaitJs("document.getElementById('term-entry-overlay').hidden && !document.body.classList.contains('modal-open')")
            eval("document.querySelector('[data-tab=\"more\"]').click();document.getElementById('account-open').click();document.getElementById('backup-export').click()")
            assertTrue("System backup picker absent", device.wait(Until.hasObject(By.pkg("com.google.android.documentsui")), 15000) || device.hasObject(By.pkg("com.android.documentsui")))
            device.pressBack()
            awaitJs("JSON.parse(localStorage.getItem('finansim-prototype-v1')).recurring.some(x=>x.name==='Android smoke')")
        } finally { scenario.close() }
    }
}
