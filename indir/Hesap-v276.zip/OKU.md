# Hesap v276 — Kredi Kartı hatırlatmaları

v275 hesaplama, form, yüzde ve yedekleme düzeltmeleri korunmuştur.

## Paket
- finans-ilk-prototip.html: Ortak iOS/Android prototipi.
- HesapAndroid/: Güncel tam Android Studio projesi.
- ios/ContentView.swift ve backup-notifications.patch: v275'te eklenen tekrarlı yedek hatırlatması desteği. Kredi kartı bildirimleri aynı mevcut native bildirim köprüsünü kullanır.

## iOS
Mevcut Xcode projenizde HTML'yi değiştirin. v275'in Swift bildirim güncellemesini henüz uygulamadıysanız ios klasöründeki yamayı karşılaştırarak aktarın. Farklı Swift sürümünüzdeki ilgisiz güncellemeleri silmeyin. Bu Linux ortamında Xcode derlemesi yapılamamıştır; gerçek iPhone üzerinde derleme ve sistem bildirimlerinin teslimatı ayrıca kontrol edilmelidir.

## Android
HesapAndroid klasörünü Android Studio → Open ile açın; JVM 21 kullanın. Telefonunuzu seçip Run ile mevcut uygulamanın üzerine yükleyin. Kaldırmayın; yerel kayıtlarınızı koruyun. Android'in üst/alt boşluk, seçici teması ve açılış görünümü korunmuştur.

## Kredi kartları
Ödemeler seçicisinde üçüncü seçenek Kredi Kartı'dır. Form doğrudan sayfadadır; Yeni Ödeme Ekle görünmez. Kart Sayısı 1–10 arasındadır. 1'den fazla kart varsa Kredi Kartını Seç kutusu görünür. Her kart için ayrı ad, son ödeme günü ve hesap kesim günü kaydedilir. Ad boş bırakıldığında Kredi Kartı / Credit Card kullanılır. Dolu kartların sayısını azaltmadan önce ilgili kartlar Sil ile kaldırılır.

Günler ayın 1–31'i arasından seçilir. Kısa aylarda 29–31 seçimi ayın son gününe alınır. Kart listesi, aylık ödeme listesi ve yaklaşan ödemeler son ödeme tarihine göre sıralanır. Kartların miktarı yoktur; aylık/yıllık ödeme toplamı ve portföy değerine katılmazlar.

Takvimde hesap kesimi ve son ödeme günleri yeşil nokta ile belirtilir. Kredi Kartı açıklaması yeşildir; normal ödeme ve vade renkleri korunur.

Hesap kesimi günü 11.00'da bir hatırlatma; son ödeme tarihinden 2 gün önce, 1 gün önce ve o gün 11.00'da üç hatırlatma zamanlanır. İsim verilmişse mesajda o isim bulunur. Dokununca Ödemeler → Kredi Kartı sayfası açılır. Saatler cihazın yerel saatidir. Bildirim izni gerekir; Android pil tasarrufu/uyku koşullarında gecikme olabilir. Mevcut iOS sınırı nedeniyle en yakın 54 ödeme/vade/kart bildirimi ve 6 tekrarlı yedek hatırlatması zamanlanır; uygulama açıldığında ve kullanılırken liste yenilenir.

## Yedek uyumluluğu
Yeni yedekler sürüm 3'tür ve kartları da içerir. Bu sürüm eski 1/2 yedeklerini de açar. Eski uygulama sürümlerine yeni yedekleri yüklemeyin; kart verilerini tanımayan eski sürümler desteklemez. Android native içe aktarma da sürüm 3 için güncellenmiştir.

## Kontroller
Geçti: kart sayısı/seçimi, gün seçici, ekle/düzenle/sil, verili yeniden açılış, isimlerin güvenli gösterimi, iki takvim tarihi, Şubat ay sonu ve ay sınırını geçen hatırlatmalar, bildirimden sayfaya yönlendirme, toplamların korunması, yedek döngüsü ve geçersiz yedek reddi. Önceki v275 hesaplama testleri de geçti.

10 kartla Türkçe/İngilizce ve 360/384/412 px ekranlarda 108 sekme geçişi: JavaScript hatası ve yatay taşma görülmedi. Android APK/AAB, beş birim testi ve lint geçti. Tarayıcı performansı gerçek cihaz akıcılığını garanti etmez; gerçek cihaz bildirim teslimatı burada ölçülmedi.
