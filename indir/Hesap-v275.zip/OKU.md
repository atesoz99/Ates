# Hesap v275 — iOS ve Android

Temel: Bu konuşmada yüklenen finans-ilk-prototip.html (SHA-256 e6821f23ffcbd317359c565bb0fd316f6eefa75697057866cba1bf3f52584a3e).

## İçerik
- finans-ilk-prototip.html: Her iki platformda kullanılan güncel ortak prototip.
- ios/ContentView.swift: Daha önce gönderilen Swift kaynak dosyasına yalnızca tekrarlı yedekleme bildirimi desteği eklenmiş hali.
- ios/backup-notifications.patch: Mevcut Swift dosyanızdaki değişikliği karşılaştırmak için küçük yama.
- HesapAndroid/: Tam güncel Android Studio projesi. local.properties, özel anahtarlar ve makineye özgü derleme dosyaları dahil değildir.
- TESTLER.md: Yapılan kontroller ve sınırları.

## iOS'a uygulama
Xcode projenizde HTML dosyasını değiştirin. Tekrarlı sistem bildirimleri için ContentView.swift değişikliğini de uygulayın. Mevcut Swift dosyanız farklıysa ios/backup-notifications.patch içindeki küçük değişikliği karşılaştırarak aktarın; ilgisiz güncellemeleri silmeyin. Bu ortamda Xcode bulunmadığından iOS derlemesi ve fiziksel iPhone testi burada yapılmadı.

## Android'e uygulama
HesapAndroid klasörünü Android Studio'da Open ile açın. Gradle JVM 21 kullanın. Telefonunuzu seçip Run ile mevcut uygulamanın üzerine yükleyin; uygulamayı kaldırmayın. Android'in üst/alt kenar boşlukları, açılış tasarımı ve seçici teması korunmuştur.

## İşlevler
- Hedef ortalama: Girilen hedef, kayıttan sonraki son ortalamadır. Geçmiş tarihli alışın birim fiyatı sonraki alış/satışlar dahil hesaplanır. TL ve ons hedefleri ayrı çözülür. Pozitif fiyatla ulaşılamayan hedef kaydedilmez. Kapalı bir geçmiş dönemin düzenlenmesi son ortalamayı etkileyemiyorsa uyarı gösterilir.
- Ortalama fiyatıyla gelir: Seçilen tarihte, işlemin öncesindeki ortalama kullanılır. Kayıt düzenlenirken kendisi hesaplamaya katılmaz.
- Vade kartı: Yatırılan Para (TL / İlk / Bugün) başlığı ve TL / ilk USD / bugünkü USD sırası.
- Vadeli TL (vadesi bugün veya ileride olanlar) ve vade dışı TL tutarları toplam yüzdelik değişimin tabanına katılır. Kâr-zarar tutarları değişmez. Ons toplamı için gerekli dolar karşılığı da yüzde tabanına eklenir.
- Al-Sat formu yıllık işlem özetinin üzerindedir. Hedef ortalama açıklaması iki dilde eklenmiştir.
- Hedef ortalama seçiliyken gelir tiki seçilebilir; gelir seçilince hedef tiki otomatik kaldırılır.
- iOS/web Vade simgesi hafifçe büyütülmüştür; Android simge ölçüleri korunur.
- Her çift ayın ilk günü cihazın yerel saatiyle 10.00'da yedekleme hatırlatması. Dokununca menüdeki Yedekle ile aynı işlem başlar. iOS'ta altı yıllık tekrarlı bildirim; Android'de altı yılda bir yeniden kurulan yerel alarm kullanılır. Ödeme/vade bildirimlerine 54, yedek hatırlatmalarına 6 yer ayrılır.

Sistem bildirimi için kullanıcı izni gerekir. Android pil tasarrufu/uyku durumu teslimatı geciktirebilir; zorla durdurulan uygulama yeniden açılana kadar bildirim alamayabilir. HTML'nin tarayıcıda açılan hali, uygulama kapalıyken native sistem bildirimi üretemez; yerel uygulama kodu da güncellenmelidir.
