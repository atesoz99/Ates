# v275 doğrulaması

Geçti:
- Geçmiş tarihli hedef son ortalamanın çözümlenmesi ve gerçek form gönderiminde hesaplanan birim fiyatın kaydedilmesi.
- Sonraki kısmi satışın ağırlığı; yeni geçmiş alışla eski sıfır noktasının bozulması; son ortalamaya etkisi olmayan kapalı dönem düzenlemesinin reddi.
- Altın için bağımsız ons hedef fiyatı.
- Geçmiş tarihli gelir kaydında o tarihin ortalaması ve iki tikin geçişi.
- TL varlıkların yüzde tabanına dahil olması ve vade kartında üçlü tutar sırası.
- Formun yıllık işlem özetinin önünde bulunması.
- Çift aylar, saat 10.00, altı tekrarlı native bildirim ve bildirime dokununca export çağrısı.
- Türkçe/İngilizce; 360/384/412 px; 108 sekme geçişinde sıfır JavaScript hatası ve yatay taşma olmaması.
- Android tarih seçme köprüsü, ödeme kaydı, yedek iptalinde kayıtların korunması, modal/geri tuşu köprüsü.
- Android üst/alt kenar boşluğu kontrolü.

Android APK/AAB, birim testleri ve lint ayrıca çalıştırılmıştır. iOS kaynak değişikliği küçük ve ayrı yama olarak verilmiştir; Xcode derlemesi bu Linux ortamında yapılamadı. Gerçek iPhone/Samsung üzerinde sistem bildirimlerinin teslimatı ve uzun süreli kullanım burada test edilmedi. Tarayıcı testi bu cihazlardaki akıcılık için garanti değildir.
